<?php require_once __DIR__ . '/../init.php'; require_once PROJECT_ROOT . '/src/db_connect.php'; ?>
require_once __DIR__ . '/../config/app.php';

// Apenas administradores
if (!isset($_SESSION['user_id']) || $_SESSION['user_level'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $empresa = $_POST['empresa'];
    $cnpj_cpf = $_POST['cnpj_cpf'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];
    $credito_permuta = $_POST['credito_permuta'];

    $stmt = $conn->prepare("INSERT INTO clientes (empresa, cnpj_cpf, email, telefone, endereco, credito_permuta) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssd", $empresa, $cnpj_cpf, $email, $telefone, $endereco, $credito_permuta);

    if ($stmt->execute()) {
        header("Location: ../clientes.php?success=1");
    } else {
        header("Location: ../clientes.php?error=1");
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../cliente_add.php");
}
exit();
