<?php
// Inclui o arquivo de inicialização a partir do diretório pai (a raiz do projeto)
require_once __DIR__ . '/../init.php';

// init.php já cuida da conexão. A linha abaixo foi removida.

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("SELECT id, nome, senha, nivel_acesso FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        if (password_verify($senha, $user['senha'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['nome'];
            $_SESSION['user_level'] = $user['nivel_acesso'];
            
            header("Location: ../dashboard.php");
            exit();
        }
    }

    header("Location: ../login.php?error=1");
    exit();
} else {
     header("Location: ../login.php");
     exit();
}
