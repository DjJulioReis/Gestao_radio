<?php require_once __DIR__ . '/../init.php'; require_once PROJECT_ROOT . '/src/db_connect.php'; ?>
require_once __DIR__ . '/../config/app.php';

// Apenas administradores
if (!isset($_SESSION['user_id']) || $_SESSION['user_level'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $empresa = $_POST['empresa'];
    $cnpj_cpf = $_POST['cnpj_cpf'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];
    $credito_permuta = $_POST['credito_permuta'];

    $stmt = $conn->prepare("UPDATE clientes SET empresa = ?, cnpj_cpf = ?, email = ?, telefone = ?, endereco = ?, credito_permuta = ? WHERE id = ?");
    $stmt->bind_param("sssssdi", $empresa, $cnpj_cpf, $email, $telefone, $endereco, $credito_permuta, $id);

    if ($stmt->execute()) {
        header("Location: ../clientes.php?success=2");
    } else {
        header("Location: ../clientes.php?error=2");
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: ../clientes.php");
}
exit();
