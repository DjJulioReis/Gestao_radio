<?php
require_once 'init.php';
$page_title = "Adicionar Cliente";

// Apenas administradores
if ($_SESSION['user_level'] !== 'admin') {
    // Redireciona para o dashboard se não for admin
    header("Location: dashboard.php");
    exit();
}
?>

<h1><?php echo $page_title; ?></h1>
<form action="src/cliente_add_handler.php" method="post">
    <div class="form-group">
        <label for="empresa">Empresa</label>
        <input type="text" name="empresa" id="empresa" required>
    </div>
    <div class="form-group">
        <label for="cnpj_cpf">CNPJ/CPF</label>
        <input type="text" name="cnpj_cpf" id="cnpj_cpf" required>
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" required>
    </div>
    <div class="form-group">
        <label for="telefone">Telefone</label>
        <input type="text" name="telefone" id="telefone">
    </div>
    <div class="form-group">
        <label for="endereco">Endereço</label>
        <input type="text" name="endereco" id="endereco">
    </div>
    <div class="form-group">
        <label for="credito_permuta">Crédito (Permuta)</label>
        <input type="number" step="0.01" name="credito_permuta" id="credito_permuta" value="0.00">
    </div>
    <button type="submit">Salvar</button>
    <a href="clientes.php" class="cancel-link">Cancelar</a>
</form>

<?php
require_once __DIR__ . '/templates/footer.php';
?>
