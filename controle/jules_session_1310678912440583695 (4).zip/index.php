// Redireciona para a página de login, que é o ponto de entrada do sistema.
header("Location: login.php");
exit();
