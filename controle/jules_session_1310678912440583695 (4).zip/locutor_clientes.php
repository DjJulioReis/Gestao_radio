$page_title = "Associar Clientes a Locutores";
require_once __DIR__ . '/templates/header.php';
require_once __DIR__ . '/src/db_connect.php';

// Apenas administradores
if ($_SESSION['user_level'] !== 'admin') {
    header("Location: dashboard.php");
    exit();
}

// Obter todos os locutores e clientes
$locutores = $conn->query("SELECT id, nome FROM locutores ORDER BY nome");
$clientes = $conn->query("SELECT id, empresa FROM clientes ORDER BY empresa");

// Obter associações existentes
$associacoes = [];
$result_assoc = $conn->query("SELECT cliente_id, locutor_id FROM clientes_locutores");
if ($result_assoc->num_rows > 0) {
    while ($row = $result_assoc->fetch_assoc()) {
        $associacoes[$row['cliente_id']] = $row['locutor_id'];
    }
}
?>

<h1><?php echo $page_title; ?></h1>
<p>Associe um locutor a cada cliente para calcular a comissão de 50% sobre os contratos.</p>

<form action="src/locutor_clientes_handler.php" method="post">
    <table>
        <thead>
            <tr>
                <th>Cliente</th>
                <th>Locutor Responsável</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($cliente = $clientes->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($cliente['empresa']); ?></td>
                    <td>
                        <select name="associacao[<?php echo $cliente['id']; ?>]">
                            <option value="">Nenhum</option>
                            <?php
                            // Resetar o ponteiro do resultado dos locutores para iterar novamente
                            $locutores->data_seek(0);
                            while ($locutor = $locutores->fetch_assoc()) {
                                $selected = (isset($associacoes[$cliente['id']]) && $associacoes[$cliente['id']] == $locutor['id']) ? 'selected' : '';
                                echo "<option value='{$locutor['id']}' {$selected}>" . htmlspecialchars($locutor['nome']) . "</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <br>
    <button type="submit">Salvar Associações</button>
</form>

<?php
$conn->close();
require_once __DIR__ . '/templates/footer.php';
?>
