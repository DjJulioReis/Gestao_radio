<?php
// Arquivo de configuração da aplicação.
// A constante BASE_PATH foi removida para usar caminhos de URL absolutos.
