<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'novaf_radio_fm');
define('DB_PASS', 'n5yfn4NkDhsdJw5hWXTt');
define('DB_NAME', 'novaf_radio_fm');
