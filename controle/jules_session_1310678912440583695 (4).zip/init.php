<?php
// init.php - Arquivo de inicialização central

// Habilita a exibição de todos os erros para depuração
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Define o caminho absoluto da raiz do projeto para inclusões de arquivos seguras.
define('PROJECT_ROOT', __DIR__);

// 2. Carrega as configurações da aplicação.
require_once PROJECT_ROOT . '/config/app.php';

// 3. Carrega as credenciais do banco de dados.
require_once PROJECT_ROOT . '/config/db.php';

// 4. Inicia a sessão de forma segura.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 5. Estabelece a conexão com o banco de dados.
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Verifica a conexão
if ($conn->connect_error) {
    // Em um ambiente de produção, logue o erro em vez de exibi-lo
    error_log("Erro de conexão com o banco de dados: " . $conn->connect_error);
    // Exibe uma mensagem genérica para o usuário
    die("Ocorreu um problema ao conectar com o sistema. Tente novamente mais tarde.");
}

// Define o charset para UTF-8 para evitar problemas com caracteres especiais
$conn->set_charset("utf8mb4");
